//
//  Login_SignIn_AppApp.swift
//  Login_SignIn_App
//
//  Created by Nguyễn Quang Anh on 22/5/25.
//

import SwiftUI

@main
struct Login_SignIn_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
